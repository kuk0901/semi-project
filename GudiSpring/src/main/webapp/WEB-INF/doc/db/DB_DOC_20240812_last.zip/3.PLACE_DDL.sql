-------------------------------------------------------------------------------
//PLACE TABLE 

-- 테이블 삭제
DROP TABLE PLACE;

-- 테이블 생성
CREATE TABLE PLACE(
    PLACE_NO NUMBER(6) NOT NULL,
    CATEGORY VARCHAR2(10) NOT NULL,
    AREA_NO NUMBER(2) NOT NULL,
    PLACE_NAME VARCHAR2(100) NOT NULL,
    PL_ADDRESS VARCHAR2(4000) NOT NULL,
    PL_PHONE VARCHAR2(30) NOT NULL,
    PL_WEBSITE VARCHAR2(50) NOT NULL,
    GEN_RESERVATION NUMBER(6) DEFAULT 0 NOT NULL,
    RECO_RESERVATION NUMBER(6) DEFAULT 0 NOT NULL
);

-- 제약사항 수정
ALTER TABLE PLACE
ADD CONSTRAINT PLACE_NO_PK PRIMARY KEY(PLACE_NO);

ALTER TABLE PLACE
ADD CONSTRAINT PL_WEBSITE_UK UNIQUE(PL_WEBSITE);

ALTER TABLE PLACE
ADD CONSTRAINT AREA_NO_FK FOREIGN KEY(AREA_NO) REFERENCES AREA (AREA_NO);

-- 시퀀스 삭제
DROP SEQUENCE PLACE_NO_SEQ;

-- 시퀀스 생성
CREATE SEQUENCE PLACE_NO_SEQ
INCREMENT BY 1
START WITH 1;

-- 데이터 삽입
--\\경기도-----------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 1, '테누커피', '서울 마포구 연남동 241-89', '050713657553', 'http://instagram.com/tenucoffee' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 1, '우나나베이크하우스', '경기 고양시 일산서구 호수로838번길 34-17 1층', '050713399338', 'https://www.instagram.com/oohnana_bakehouse' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 1, '오모나', '경기 연천군 청산면 청창로 469 오모나', '050714497529', 'https://www.instagram.com/omona_cafe' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 1, 'HIDE 방배', '서울 서초구 방배중앙로 164', '07042421807', 'https://www.instagram.com/hideseoul_official' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 1, '프로방스하우스', '경기 파주시 운정4길 150 프로방스하우스', '050713503884', 'http://site.onda.me/135450' , 0, 0);
--//강원도--------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 2, '슬로우 26', '강원 평창군 봉평면 메밀꽃길 26 슬로우26', '050714903314', 'https://www.instagram.com/slow_at_26' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 2, '카페 이루아', '강원 평창군 봉평면 태기로 303', '01089533616', 'https://blog.naver.com/g10005' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 2, '풀내음', '강원 평창군 봉평면 메밀꽃길 13', '0333350034', 'https://www.instagram.com/pulnaeum2001' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 2, '풀내음', '강원 평창군 봉평면 메밀꽃길 13', '0333350034', 'https://www.instagram.com/pulnaeum2001' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 2, '힐링하시개', '강원 평창군 봉평면 안흥동길 132-7 힐링하시개', '01094802327', 'http://xn--h49at2x25g1itdrc.kr' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 2, '코코애견펜션', '강원 홍천군 북방면 노일로238번길 72-10 코코애견펜션', '07043649508', 'http://www.cocodogpension.co.kr/' , 0, 0);
--\\충청도-----------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 3, '썬하우스', '대전 서구 탄방로 29 1층', '050713130757', 'http://www.instargram.com/ssunhouse_sh/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 3, '리리스카페', '충남 보령시 성주면 개화리 177-2', '07041332845', 'http://www.ririss.com/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 3, '성주', '대전 서구 문정로112번안길 55 1층 101호', '050713470156', 'https://www.instagram.com/sungzou.bottle.shop' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 3, 'LITTLE TAP', '대전 유성구 노은로 150 드래곤랜드', '0428252280', 'http://www.facebook.com/littletapbeer' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 3, '서동선화한옥', '충남 부여군 부여읍 월함로 105-1 서동 선화 한옥', '01096460182', 'https://blog.naver.com/kyple22' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 3, '안스테이펜션', '충남 금산군 부리면 적벽강로 332-11 안스테이 펜션', '050713536135', 'https://www.instagram.com/ann_stay_pension/' , 0, 0);
--\\전라도-----------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 4, '피읖카페', '전남 여수시 돌산읍 돌산로 3292-6 피읖카페', '0616433292', 'https://www.instagram.com/pieup_cafe' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 4, '콜리스', '전남 진도군 군내면 정거름재길 70-15', '0615440207', 'https://www.instagram.com/collis_0615440207' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 4, '내소식당', '전북 부안군 진서면 내소사로 181 내소식당', '050713637281', 'http://instagram.com/naeso_sikdang' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 4, '여울목', '전북 완주군 소양면 오도길 131-1', '0632478193', 'https://blog.naver.com/gustnr3114' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 4, '순천만 무한도전 애견동반펜션', '전남 순천시 순천만길 336', '07043649323', 'http://무한도전펜션.kr/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 4, '여수 슈가몽544', '전남 여수시 고소1길 57', '01022725879', 'https://yeosusugarmong544.co.kr' , 0, 0);
--\\경상도-----------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 5, '별꽃자리', '대구 북구 동변로24길 64', '050713886326', 'https://www.instagram.com/star_zary/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 5, '간절바당', '울산 울주군 서생면 신암해안길 11', '050713766163', 'http://www.instagram.com/ganjeolbadang' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 5, '살롱드인사', '경남 진주시 창렬로 12 살롱드인사', '050713907832', 'https://www.instargram.com/salon_de_insa/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 5, '묏골관광농원식당', '경남 함양군 병곡면 묘동길 105', '050713448143', 'http://www.mkck.kr' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 5, '블루캐슬펜션', '경남 거제시 일운면 거제대로 1447', '050713622918', 'http://xn--l89a05uq3dv0ds1bw2g06u2vi.com/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 5, '팔공힐링펜션', '대구 군위군 부계면 한티로 1751', '01071246994', 'https://www.instagram.com/gout__cafe/' , 0, 0);
--\\제주도-----------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 6, '제이아일랜드', '제주 서귀포시 성산읍 환해장성로 69 제이아일랜드', '050714417077', 'https://www.instagram.com/j_islandcafe/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '카페', 6, '그초록', '제주 제주시 구좌읍 행원로7길 23-16 1층(바닷가앞)', '050713234244', 'https://www.instagram.com/the_green_cafe/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 6, '평대리멍석', '제주 제주시 구좌읍 해맞이해안로 1308 평대리 멍석', '0647828983', 'https://www.instagram.com/pd_met/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '식당', 6, '마씸', '제주 서귀포시 성산읍 환해장성로 129-1', '050713370768', 'https://www.instagram.com/massim___jeju/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 6, '돔그라미', '제주 서귀포시 표선면 가시로 137 돔그라미 펜션', '01021460271', 'https://www.jejudomgrami.com/' , 0, 0);

INSERT INTO PLACE
(PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION)
VALUES (PLACE_NO_SEQ.NEXTVAL, '펜션', 6, '애견펜션하젠', '제주 서귀포시 표선면 토산중앙로 140', '050713055064', 'https://hazen.modoo.at/' , 0, 0);

-- GEN_RESERVATION 수정
UPDATE PLACE
SET GEN_RESERVATION = GEN_RESERVATION + 1
WHERE PLACE_NO = 1;

-- RECO_RESERVATION 수정

UPDATE PLACE
SET RECO_RESERVATION = RECO_RESERVATION + 1
WHERE PLACE_NO = 2;


-- 데이터 확인
SELECT PLACE_NO, CATEGORY, AREA_NO, PLACE_NAME, PL_ADDRESS, PL_PHONE, PL_WEBSITE, GEN_RESERVATION, RECO_RESERVATION
FROM PLACE;

-- 커밋
COMMIT;
-------------------------------------------------------------------------------